package com.ibm.ms2.service;

import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.ibm.ms2.exception.RecordNotFoundException;
import com.ibm.ms2.model.ConvertCurrencyEntity;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/*
 * @Shabbir Ali -04872S
 */

@Service
public class ConvertCurrencyService {

	@Autowired
	FeignCurrencyServiceProxy proxyService;

	@HystrixCommand(fallbackMethod = "callActivityMS1Failure")// Fall back method
	public ConvertCurrencyEntity convertCurrencyToAmount(ConvertCurrencyEntity entity)  {
		Double convertedAmount = 0.0;
		//Commented - to use Feign
		// final String U RL = "http://localhost:8080/currencyConversion/" +entity.getCountryCode();
		ConvertCurrencyEntity convertCurrencyEntity = null;
		try {
			//Replacing Rest template for Feign
			/* RestTemplate restTemplate = new RestTemplate();
			 ResponseEntity<ConvertCurrencyEntity> response =
			 restTemplate.getForEntity(URL, ConvertCurrencyEntity.class);*/
			//End
			ResponseEntity<ConvertCurrencyEntity> response = proxyService.findByCuntryCode(entity.getCountryCode());
			if (null != response) {
				convertCurrencyEntity = new ConvertCurrencyEntity();
				String conversionFactor = response.getBody().getConversionFactor();
				Double convertedFactor = Double.parseDouble(conversionFactor);
				convertedAmount = convertedFactor * entity.getAmount();
				convertCurrencyEntity.setCountryCode(entity.getCountryCode());
				convertCurrencyEntity.setConversionFactor(conversionFactor);
				convertCurrencyEntity.setAmount(convertedAmount);
				return convertCurrencyEntity;
			} else {
				return convertCurrencyEntity;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return convertCurrencyEntity;
		}
		
	}
	//Method to check Load Balancing through Ribbon - call MS1 from MS2
	public String getPortToCheckRibbonFromMS1(){
		return proxyService.getPortNumberthroughRibbon();
		
	}
	
	//Method to check Hystrix fault tolerance - Enable the Hystrix Circuit Breaker for MS-1
	@SuppressWarnings("unused")
    public String callActivityMS1Failure() {
 
        System.out.println("Activity1MS1!!! fallback route enabled...");
        return "Hytrix CIRCUIT BREAKER ENABLED!!! No Response From Activity1MS1 Service at this moment. " +" Service will be back shortly - " + new Date();
    }
	
	
}