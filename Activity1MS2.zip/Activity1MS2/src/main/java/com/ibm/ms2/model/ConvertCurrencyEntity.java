package com.ibm.ms2.model;

import java.util.Date;

/*
 * @Shabbir Ali -04872S
 */
public class ConvertCurrencyEntity {

	private String countryCode;
	
	
	private String conversionFactor;
	
	private double amount;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "ConvertCurrencyEntity [countryCode=" + countryCode + ", amount="
				+ amount + "]";
	}

	public String getConversionFactor() {
		return conversionFactor;
	}

	
	public void setConversionFactor(String conversionFactor) {
		this.conversionFactor = conversionFactor;
	}
	
	//Method to check Hystrix fault tolerance - Enable the Hystrix Circuit Breaker for MS-1
    @SuppressWarnings("unused")
	private String callActivityMS1Failure() {
	 System.out.println("Activity1MS1!!! fallback route enabled...");
	 return "Hytrix CIRCUIT BREAKER ENABLED!!! No Response From Activity1MS1 Service at this moment. " +" Service will be back shortly - " + new Date();
	    }
		
}