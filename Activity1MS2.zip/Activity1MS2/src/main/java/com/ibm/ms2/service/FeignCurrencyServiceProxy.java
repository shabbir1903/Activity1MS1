package com.ibm.ms2.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ibm.ms2.model.ConvertCurrencyEntity;

/*
 * @Shabbir Ali -04872S
 */

@FeignClient(name="Activity1MS1" )//This value is the name of the service registered using Eureka for discovery
public interface FeignCurrencyServiceProxy {

	 @RequestMapping("/currencyConversion/{countryCode}")
	 public ResponseEntity<ConvertCurrencyEntity> findByCuntryCode(@PathVariable(value="countryCode") String countryCode);
	 
	 //To check Load Balancing through ribbon
	 @RequestMapping("/currencyConversion/backend") // Mapping is there in MS1 currencyConversion/backend
	 public String getPortNumberthroughRibbon();

}
