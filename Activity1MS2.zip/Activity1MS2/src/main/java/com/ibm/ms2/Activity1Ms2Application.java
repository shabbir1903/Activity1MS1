package com.ibm.ms2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;

/*
 * @Shabbir Ali -04872S
 */

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients // Enabling Feigns
@EnableHystrix
@EnableCircuitBreaker
public class Activity1Ms2Application {

	public static void main(String[] args) {
		SpringApplication.run(Activity1Ms2Application.class, args);
	}

}
