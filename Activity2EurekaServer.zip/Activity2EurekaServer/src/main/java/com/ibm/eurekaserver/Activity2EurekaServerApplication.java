package com.ibm.eurekaserver;

/*
 * @Shabbir Ali -04872S
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class Activity2EurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Activity2EurekaServerApplication.class, args);
	}

}
